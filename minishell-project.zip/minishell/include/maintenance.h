/* maintenance.h - automated housekeeping tasks */
#ifndef MAINTENANCE_H
#define MAINTENANCE_H

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    long examined;
    long matched;         /* files older than the threshold with a safe suffix */
    long removed;         /* only non-zero when force != 0                     */
    long long bytes;
} CleanupResult;

/* Removes *.tmp, *.log, *.bak files in dir (non recursive) older than `days`.
 * Dry-run unless force != 0. Returns 0 or -1 if dir cannot be opened. */
int cleanup_dir(const char *dir, int days, int force, FILE *out, CleanupResult *res);

#ifdef __cplusplus
}
#endif
#endif /* MAINTENANCE_H */
