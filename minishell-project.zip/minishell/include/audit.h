/* audit.h - audit trail recording and report generation */
#ifndef AUDIT_H
#define AUDIT_H

#include "logger.h"
#include <stdio.h>
#include <sys/types.h>

#ifdef __cplusplus
extern "C" {
#endif

#define AUDIT_TOP_N 5

typedef struct {
    char name[64];
    long count;
} CmdCount;

typedef struct {
    long total;
    long succeeded;
    long failed;
    int  ntop;
    CmdCount top[AUDIT_TOP_N];
    char first_ts[32];
    char last_ts[32];
} AuditSummary;

/* Record format:  timestamp|user|pid|exit_status|command */
void audit_record(Logger *lg, const char *user, pid_t pid, int status, const char *cmd);
int  audit_summarize(const char *path, AuditSummary *out);     /* -1: cannot open */
void audit_print_report(const AuditSummary *s, FILE *out);
int  audit_tail(const char *path, int n, FILE *out);

#ifdef __cplusplus
}
#endif
#endif /* AUDIT_H */
