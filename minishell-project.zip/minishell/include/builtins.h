/* builtins.h - built-in commands, including infrastructure management tools */
#ifndef BUILTINS_H
#define BUILTINS_H

#include "shell.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef int (*builtin_fn)(Shell *sh, int argc, char **argv);

typedef struct {
    const char *name;
    builtin_fn  fn;
    const char *usage;
    const char *help;
} Builtin;

int  builtin_is(const char *name);
int  builtin_run(Shell *sh, int argc, char **argv);
const Builtin *builtin_table(size_t *count);

#ifdef __cplusplus
}
#endif
#endif /* BUILTINS_H */
