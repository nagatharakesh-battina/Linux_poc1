/* utils.h - small helpers: safe allocation, dynamic string buffer, parsing */
#ifndef UTILS_H
#define UTILS_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Growable string buffer */
typedef struct {
    char  *buf;
    size_t len;
    size_t cap;
} StrBuf;

void  sb_init(StrBuf *sb);
void  sb_putc(StrBuf *sb, char c);
void  sb_puts(StrBuf *sb, const char *s);
char *sb_take(StrBuf *sb);   /* returns heap string (never NULL), buffer is reset */
void  sb_free(StrBuf *sb);

/* Allocation wrappers: abort with a message on out-of-memory */
void *xmalloc(size_t n);
void *xcalloc(size_t n, size_t sz);
void *xrealloc(void *p, size_t n);
char *xstrdup(const char *s);

/* String helpers */
char *str_trim(char *s);                         /* trims in place, returns s    */
int   str_starts_with(const char *s, const char *prefix);
int   str_ends_with(const char *s, const char *suffix);
int   parse_long(const char *s, long *out);      /* 0 on success, -1 on error     */

#ifdef __cplusplus
}
#endif
#endif /* UTILS_H */
