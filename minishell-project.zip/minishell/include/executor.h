/* executor.h - fork/exec, pipes, redirection, background execution (Level 2-4,6) */
#ifndef EXECUTOR_H
#define EXECUTOR_H

#include "jobs.h"
#include "parser.h"
#include "shell.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Runs a parsed pipeline. cmdline is stored in the job table. Returns status. */
int execute_pipeline(Shell *sh, Pipeline *p, const char *cmdline);

/* Brings a job to the foreground (used by `fg`). Returns its status. */
int executor_foreground_job(Shell *sh, Job *job);

#ifdef __cplusplus
}
#endif
#endif /* EXECUTOR_H */
