/* shell.c - shell lifecycle, prompt, read-eval loop, audit hook */
#include "shell.h"
#include "audit.h"
#include "executor.h"
#include "parser.h"
#include "utils.h"

#include <errno.h>
#include <pwd.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static void on_sigint(int sig) { (void)sig; }   /* only interrupts the blocking read */

static void setup_interactive_signals(Shell *sh)
{
    struct sigaction ign, intr;

    memset(&ign, 0, sizeof ign);
    ign.sa_handler = SIG_IGN;
    sigemptyset(&ign.sa_mask);
    sigaction(SIGQUIT, &ign, NULL);
    sigaction(SIGTSTP, &ign, NULL);
    sigaction(SIGTTIN, &ign, NULL);
    sigaction(SIGTTOU, &ign, NULL);

    memset(&intr, 0, sizeof intr);
    intr.sa_handler = on_sigint;              /* no SA_RESTART: getline() returns */
    sigemptyset(&intr.sa_mask);
    sigaction(SIGINT, &intr, NULL);

    setpgid(0, 0);                            /* become group leader (may fail harmlessly) */
    sh->pgid = getpgrp();
    tcsetpgrp(STDIN_FILENO, sh->pgid);
}

static const char *current_user(void)
{
    const char *u = getenv("USER");
    if (u && *u) return u;
    struct passwd *pw = getpwuid(getuid());
    return pw ? pw->pw_name : "user";
}

int shell_init(Shell *sh, const char *state_dir, int interactive)
{
    const char *base;

    memset(sh, 0, sizeof *sh);
    sh->running = 1;
    sh->interactive = interactive;
    sh->save_history = interactive;
    sh->pgid = getpgrp();

    if (state_dir && *state_dir) {
        snprintf(sh->state_dir, sizeof sh->state_dir, "%s", state_dir);
    } else if ((base = getenv("MINISHELL_HOME")) && *base) {
        snprintf(sh->state_dir, sizeof sh->state_dir, "%s", base);
    } else if ((base = getenv("HOME")) && *base) {
        snprintf(sh->state_dir, sizeof sh->state_dir, "%s/.minishell", base);
    } else {
        snprintf(sh->state_dir, sizeof sh->state_dir, "/tmp/minishell-%d", (int)getuid());
    }
    if (mkdir(sh->state_dir, 0700) != 0 && errno != EEXIST) {
        fprintf(stderr, "minishell: cannot create %s: %s\n", sh->state_dir, strerror(errno));
        snprintf(sh->state_dir, sizeof sh->state_dir, "/tmp/minishell-%d", (int)getuid());
        mkdir(sh->state_dir, 0700);
    }
    snprintf(sh->history_path, sizeof sh->history_path, "%s/history", sh->state_dir);
    snprintf(sh->audit_path,   sizeof sh->audit_path,   "%s/audit.log", sh->state_dir);
    snprintf(sh->alert_path,   sizeof sh->alert_path,   "%s/alerts.log", sh->state_dir);

    history_init(&sh->history, 500);
    if (interactive)
        history_load(&sh->history, sh->history_path);
    jobs_init(&sh->jobs);
    if (logger_open(&sh->audit_log, sh->audit_path) != 0)
        fprintf(stderr, "minishell: warning: audit log disabled (%s)\n", strerror(errno));
    if (logger_open(&sh->alert_log, sh->alert_path) != 0)
        fprintf(stderr, "minishell: warning: alert log disabled (%s)\n", strerror(errno));
    monitor_init(&sh->monitor, &sh->alert_log);

    if (interactive)
        setup_interactive_signals(sh);
    return 0;
}

void shell_destroy(Shell *sh)
{
    monitor_destroy(&sh->monitor);
    if (sh->save_history)
        history_save(&sh->history, sh->history_path);
    history_destroy(&sh->history);
    jobs_destroy(&sh->jobs);
    logger_close(&sh->audit_log);
    logger_close(&sh->alert_log);
}

void prompt_build(char *buf, size_t len, int color, const char *user,
                  const char *host, const char *cwd, const char *home)
{
    char shown[PATH_MAX];
    size_t hl = home ? strlen(home) : 0;

    snprintf(shown, sizeof shown, "%s", cwd);
    if (hl > 1 && strncmp(cwd, home, hl) == 0 && (cwd[hl] == '/' || cwd[hl] == '\0'))
        snprintf(shown, sizeof shown, "~%s", cwd + hl);

    if (color)
        snprintf(buf, len, "\033[1;32m%s@%s\033[0m:\033[1;34m%s\033[0m$ ", user, host, shown);
    else
        snprintf(buf, len, "%s@%s:%s$ ", user, host, shown);
}

/* ---- command sequencing: ';'  '&&'  '||' (quote aware) ------------------ */

typedef enum { SEQ_FIRST = 0, SEQ_SEMI, SEQ_AND, SEQ_OR } SeqOp;

typedef struct {
    char  *text;
    SeqOp  op;          /* operator that precedes this segment */
} Segment;

static void seg_push(Segment **v, size_t *n, size_t *cap, const char *s, size_t len, SeqOp op)
{
    if (*n == *cap) {
        *cap = *cap ? *cap * 2 : 8;
        *v = xrealloc(*v, *cap * sizeof **v);
    }
    (*v)[*n].text = xcalloc(len + 1, 1);
    memcpy((*v)[*n].text, s, len);
    (*v)[*n].op = op;
    (*n)++;
}

/* Splits line on unquoted ';', '&&', '||'. Caller frees each text and the array. */
static size_t split_sequence(const char *line, Segment **out)
{
    size_t n = 0, cap = 0, start = 0, i = 0;
    SeqOp op = SEQ_FIRST;
    char quote = 0;

    *out = NULL;
    while (line[i]) {
        char c = line[i];
        if (quote) {
            if (c == '\\' && quote == '"' && line[i + 1]) i++;
            else if (c == quote) quote = 0;
            i++;
            continue;
        }
        if (c == '\\' && line[i + 1]) { i += 2; continue; }
        if (c == '\'' || c == '"') { quote = c; i++; continue; }
        if (c == '#' && (i == 0 || line[i - 1] == ' ' || line[i - 1] == '\t'))
            break;                                         /* comment: ignore rest */
        if (c == ';') {
            seg_push(out, &n, &cap, line + start, i - start, op);
            op = SEQ_SEMI; i++; start = i;
        } else if (c == '&' && line[i + 1] == '&') {
            seg_push(out, &n, &cap, line + start, i - start, op);
            op = SEQ_AND; i += 2; start = i;
        } else if (c == '|' && line[i + 1] == '|') {
            seg_push(out, &n, &cap, line + start, i - start, op);
            op = SEQ_OR; i += 2; start = i;
        } else {
            i++;
        }
    }
    seg_push(out, &n, &cap, line + start, i - start, op);
    return n;
}

/* Parse and execute exactly one pipeline. */
static int run_segment(Shell *sh, const char *text)
{
    char err[256];
    Pipeline p;
    ParseStatus ps;
    int status;

    parser_set_last_status(sh->last_status);
    ps = parse_line(text, &p, err, sizeof err);
    if (ps == PARSE_EMPTY)
        return sh->last_status;

    if (ps == PARSE_ERROR) {
        fprintf(stderr, "minishell: %s\n", err);
        status = 2;
    } else {
        status = execute_pipeline(sh, &p, text);
        pipeline_free(&p);
    }
    sh->last_status = status;
    audit_record(&sh->audit_log, current_user(), getpid(), status, text);
    return status;
}

int shell_run_line(Shell *sh, const char *line)
{
    char *copy = xstrdup(line);
    char *text, *expanded = NULL;
    Segment *segs;
    size_t nseg;
    int hx;

    text = str_trim(copy);                       /* strips the trailing newline */

    hx = history_expand(&sh->history, text, &expanded);
    if (hx < 0) {
        fprintf(stderr, "minishell: %s: event not found\n", text);
        sh->last_status = 1;
        free(copy);
        return 1;
    }
    if (hx > 0) {
        printf("%s\n", expanded);
        free(copy);
        copy = expanded;
        text = str_trim(copy);
    }

    if (*text && *text != '#' && sh->script_depth == 0)
        history_add(&sh->history, text);

    nseg = split_sequence(text, &segs);
    for (size_t i = 0; i < nseg; i++) {
        int skip = (segs[i].op == SEQ_AND && sh->last_status != 0) ||
                   (segs[i].op == SEQ_OR  && sh->last_status == 0);
        if (!skip && sh->running)
            run_segment(sh, segs[i].text);
        free(segs[i].text);
    }
    free(segs);
    free(copy);
    return sh->last_status;
}

int shell_run_stream(Shell *sh, FILE *in)
{
    char *line = NULL;
    size_t cap = 0;

    while (sh->running && getline(&line, &cap, in) != -1) {
        shell_run_line(sh, line);
        jobs_update(&sh->jobs);
        if (sh->interactive)
            jobs_notify_done(&sh->jobs, stderr);
    }
    free(line);
    return sh->running ? sh->last_status : sh->exit_code;
}

int shell_repl(Shell *sh)
{
    char *line = NULL;
    size_t cap = 0;
    char host[256] = "localhost";

    gethostname(host, sizeof host - 1);
    host[sizeof host - 1] = '\0';

    while (sh->running) {
        char prompt[PATH_MAX + 600], cwd[PATH_MAX];

        jobs_update(&sh->jobs);
        jobs_notify_done(&sh->jobs, stderr);

        if (!getcwd(cwd, sizeof cwd)) snprintf(cwd, sizeof cwd, "?");
        prompt_build(prompt, sizeof prompt, 1, current_user(), host, cwd, getenv("HOME"));
        fputs(prompt, stderr);
        fflush(stderr);

        if (getline(&line, &cap, stdin) == -1) {
            if (feof(stdin)) {
                fputs("exit\n", stderr);
                break;
            }
            clearerr(stdin);                  /* interrupted by Ctrl-C */
            fputc('\n', stderr);
            continue;
        }
        shell_run_line(sh, line);
    }
    free(line);
    return sh->running ? sh->last_status : sh->exit_code;
}
