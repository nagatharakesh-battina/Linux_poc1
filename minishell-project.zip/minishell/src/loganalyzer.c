/* loganalyzer.c - each file is analysed by a worker thread of the pool */
#include "loganalyzer.h"
#include "threadpool.h"
#include "utils.h"

#include <stdlib.h>
#include <string.h>
#include <strings.h>

int analyze_file(const char *path, const char *pattern, LogStats *st)
{
    FILE *fp;
    char *line = NULL;
    size_t cap = 0;

    memset(st, 0, sizeof *st);
    snprintf(st->path, sizeof st->path, "%s", path);
    fp = fopen(path, "r");
    if (!fp)
        return -1;

    while (getline(&line, &cap, fp) != -1) {
        st->lines++;
        if (strcasestr(line, "error")) st->errors++;
        if (strcasestr(line, "warn"))  st->warnings++;
        if (strcasestr(line, "info"))  st->infos++;
        if (pattern && *pattern && strstr(line, pattern)) st->matches++;
    }
    free(line);
    fclose(fp);
    st->ok = 1;
    return 0;
}

typedef struct {
    const char *path;
    const char *pattern;
    LogStats   *out;
} AnalyzeJob;

static void analyze_task(void *arg)
{
    AnalyzeJob *j = arg;
    analyze_file(j->path, j->pattern, j->out);   /* each task owns its result slot */
}

int analyze_files_parallel(char **paths, int n, const char *pattern,
                           int nthreads, LogStats *results)
{
    ThreadPool *tp;
    AnalyzeJob *jobs;

    if (n <= 0) return 0;
    if (nthreads > n) nthreads = n;
    tp = tp_create(nthreads);
    if (!tp) return -1;
    jobs = xcalloc((size_t)n, sizeof *jobs);

    for (int i = 0; i < n; i++) {
        jobs[i].path = paths[i];
        jobs[i].pattern = pattern;
        jobs[i].out = &results[i];
        tp_submit(tp, analyze_task, &jobs[i]);
    }
    tp_wait(tp);
    tp_destroy(tp);
    free(jobs);
    return 0;
}

void log_stats_total(const LogStats *r, int n, LogStats *total)
{
    memset(total, 0, sizeof *total);
    snprintf(total->path, sizeof total->path, "TOTAL");
    total->ok = 1;
    for (int i = 0; i < n; i++) {
        total->lines    += r[i].lines;
        total->errors   += r[i].errors;
        total->warnings += r[i].warnings;
        total->infos    += r[i].infos;
        total->matches  += r[i].matches;
    }
}

void log_stats_print(const LogStats *r, int n, const char *pattern, FILE *out)
{
    LogStats total;
    fprintf(out, "%-32s %8s %8s %8s %8s", "FILE", "LINES", "ERRORS", "WARN", "INFO");
    if (pattern && *pattern) fprintf(out, " %8s", "MATCH");
    fputc('\n', out);
    for (int i = 0; i < n; i++) {
        if (!r[i].ok) {
            fprintf(out, "%-32s  (cannot read)\n", r[i].path);
            continue;
        }
        fprintf(out, "%-32.32s %8ld %8ld %8ld %8ld", r[i].path, r[i].lines,
                r[i].errors, r[i].warnings, r[i].infos);
        if (pattern && *pattern) fprintf(out, " %8ld", r[i].matches);
        fputc('\n', out);
    }
    log_stats_total(r, n, &total);
    fprintf(out, "%-32s %8ld %8ld %8ld %8ld", "TOTAL", total.lines, total.errors,
            total.warnings, total.infos);
    if (pattern && *pattern) fprintf(out, " %8ld", total.matches);
    fputc('\n', out);
}
