/* logger.c - mutex protected file logger shared by shell and monitor thread */
#include "logger.h"

#include <stdarg.h>
#include <string.h>
#include <time.h>

int logger_open(Logger *lg, const char *path)
{
    memset(lg, 0, sizeof *lg);
    pthread_mutex_init(&lg->lock, NULL);
    lg->fp = fopen(path, "a");
    if (!lg->fp)
        return -1;
    snprintf(lg->path, sizeof lg->path, "%s", path);
    return 0;
}

void logger_write(Logger *lg, const char *fmt, ...)
{
    va_list ap;
    if (!lg || !lg->fp)
        return;
    pthread_mutex_lock(&lg->lock);
    va_start(ap, fmt);
    vfprintf(lg->fp, fmt, ap);
    va_end(ap);
    fputc('\n', lg->fp);
    fflush(lg->fp);
    pthread_mutex_unlock(&lg->lock);
}

void logger_close(Logger *lg)
{
    if (!lg)
        return;
    if (lg->fp) {
        fclose(lg->fp);
        lg->fp = NULL;
    }
    pthread_mutex_destroy(&lg->lock);
}

void log_timestamp(char *buf, size_t len)
{
    time_t now = time(NULL);
    struct tm tmv;
    localtime_r(&now, &tmv);
    strftime(buf, len, "%Y-%m-%d %H:%M:%S", &tmv);
}
