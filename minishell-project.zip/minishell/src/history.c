/* history.c - linked-list command history with file persistence */
#include "history.h"
#include "utils.h"

#include <ctype.h>
#include <stdlib.h>
#include <string.h>

void history_init(History *h, int max_entries)
{
    h->head = h->tail = NULL;
    h->count = 0;
    h->max = max_entries > 0 ? max_entries : 500;
    h->next_number = 1;
}

void history_clear(History *h)
{
    HistEntry *e = h->head;
    while (e) {
        HistEntry *n = e->next;
        free(e->line);
        free(e);
        e = n;
    }
    h->head = h->tail = NULL;
    h->count = 0;
}

void history_destroy(History *h) { history_clear(h); }

static int is_blank(const char *s)
{
    while (*s) {
        if (!isspace((unsigned char)*s)) return 0;
        s++;
    }
    return 1;
}

int history_add(History *h, const char *line)
{
    HistEntry *e;
    if (!line || is_blank(line))
        return 0;
    if (h->tail && strcmp(h->tail->line, line) == 0)
        return 0;                                  /* skip consecutive duplicate */

    e = xcalloc(1, sizeof *e);
    e->line = xstrdup(line);
    e->number = h->next_number++;
    if (h->tail) h->tail->next = e; else h->head = e;
    h->tail = e;
    h->count++;

    while (h->count > h->max) {                    /* drop oldest */
        HistEntry *old = h->head;
        h->head = old->next;
        free(old->line);
        free(old);
        h->count--;
    }
    return 1;
}

const char *history_get(const History *h, int number)
{
    for (HistEntry *e = h->head; e; e = e->next)
        if (e->number == number)
            return e->line;
    return NULL;
}

const char *history_last(const History *h)
{
    return h->tail ? h->tail->line : NULL;
}

void history_print(const History *h, int last_n, FILE *out)
{
    int skip = 0;
    if (last_n > 0 && last_n < h->count)
        skip = h->count - last_n;
    for (HistEntry *e = h->head; e; e = e->next) {
        if (skip > 0) { skip--; continue; }
        fprintf(out, "%5d  %s\n", e->number, e->line);
    }
}

int history_expand(const History *h, const char *line, char **out)
{
    const char *p = line;
    size_t tok;
    const char *repl = NULL;
    StrBuf sb;

    *out = NULL;
    while (isspace((unsigned char)*p)) p++;
    if (p[0] != '!' || p[1] == '\0' || isspace((unsigned char)p[1]) || p[1] == '=')
        return 0;

    tok = 1;
    while (p[tok] && !isspace((unsigned char)p[tok])) tok++;

    if (p[1] == '!' && tok == 2) {
        repl = history_last(h);
    } else if (isdigit((unsigned char)p[1])) {
        repl = history_get(h, atoi(p + 1));
    } else {
        char prefix[256];
        size_t n = tok - 1 < sizeof prefix - 1 ? tok - 1 : sizeof prefix - 1;
        memcpy(prefix, p + 1, n);
        prefix[n] = '\0';
        for (HistEntry *e = h->head; e; e = e->next)   /* most recent match wins */
            if (str_starts_with(e->line, prefix))
                repl = e->line;
    }
    if (!repl)
        return -1;

    sb_init(&sb);
    sb_puts(&sb, repl);
    sb_puts(&sb, p + tok);
    *out = sb_take(&sb);
    return 1;
}

int history_load(History *h, const char *path)
{
    FILE *fp = fopen(path, "r");
    char *line = NULL;
    size_t cap = 0;
    ssize_t n;

    if (!fp) return -1;
    while ((n = getline(&line, &cap, fp)) != -1) {
        while (n > 0 && (line[n - 1] == '\n' || line[n - 1] == '\r'))
            line[--n] = '\0';
        history_add(h, line);
    }
    free(line);
    fclose(fp);
    return 0;
}

int history_save(const History *h, const char *path)
{
    FILE *fp = fopen(path, "w");
    if (!fp) return -1;
    for (HistEntry *e = h->head; e; e = e->next)
        fprintf(fp, "%s\n", e->line);
    return fclose(fp) == 0 ? 0 : -1;
}
