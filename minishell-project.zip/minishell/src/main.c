/* main.c - entry point: interactive shell, -c "cmd", or script file */
#include "shell.h"

#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define VERSION "1.0.0"

static void usage(void)
{
    puts("MiniShell " VERSION " - bash-like shell for IT infrastructure management\n"
         "usage: minishell                 interactive shell\n"
         "       minishell -c \"command\"    run one command line\n"
         "       minishell script.msh      run a script\n"
         "       minishell --help | --version\n"
         "State directory: $MINISHELL_HOME (default ~/.minishell)");
}

int main(int argc, char **argv)
{
    Shell sh;
    int rc;

    if (argc >= 2 && (strcmp(argv[1], "--help") == 0 || strcmp(argv[1], "-h") == 0)) {
        usage();
        return 0;
    }
    if (argc >= 2 && strcmp(argv[1], "--version") == 0) {
        puts("minishell " VERSION);
        return 0;
    }

    if (argc >= 3 && strcmp(argv[1], "-c") == 0) {
        shell_init(&sh, NULL, 0);
        rc = shell_run_line(&sh, argv[2]);
        if (!sh.running) rc = sh.exit_code;
        shell_destroy(&sh);
        return rc;
    }

    if (argc >= 2) {
        FILE *fp = fopen(argv[1], "r");
        if (!fp) {
            perror(argv[1]);
            return 127;
        }
        shell_init(&sh, NULL, 0);
        rc = shell_run_stream(&sh, fp);
        fclose(fp);
        shell_destroy(&sh);
        return rc;
    }

    if (isatty(STDIN_FILENO)) {
        shell_init(&sh, NULL, 1);
        fprintf(stderr, "MiniShell %s - type 'help' for commands, 'exit' to quit\n", VERSION);
        monitor_start(&sh.monitor, 5000);
        rc = shell_repl(&sh);
    } else {
        shell_init(&sh, NULL, 0);
        rc = shell_run_stream(&sh, stdin);
    }
    shell_destroy(&sh);
    return rc;
}
