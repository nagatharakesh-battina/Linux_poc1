/* executor.c - process creation, pipes, redirection and job control */
#include "executor.h"
#include "builtins.h"

#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

/* ---- redirection (dup2) ---------------------------------------------- */

static int apply_redirections(const Command *c)
{
    if (c->infile) {
        int fd = open(c->infile, O_RDONLY);
        if (fd < 0) {
            fprintf(stderr, "minishell: %s: %s\n", c->infile, strerror(errno));
            return -1;
        }
        dup2(fd, STDIN_FILENO);
        close(fd);
    }
    if (c->outfile) {
        int flags = O_WRONLY | O_CREAT | (c->append ? O_APPEND : O_TRUNC);
        int fd = open(c->outfile, flags, 0644);
        if (fd < 0) {
            fprintf(stderr, "minishell: %s: %s\n", c->outfile, strerror(errno));
            return -1;
        }
        dup2(fd, STDOUT_FILENO);
        close(fd);
    }
    return 0;
}

/* Builtin executed in the shell process itself (so `cd`, `export`, `exit`
 * affect the shell). Redirections are applied to saved/restored descriptors. */
static int run_builtin_in_parent(Shell *sh, Command *c)
{
    int status, save_in, save_out;

    fflush(stdout);
    fflush(stderr);
    save_in = dup(STDIN_FILENO);
    save_out = dup(STDOUT_FILENO);

    if (apply_redirections(c) < 0)
        status = 1;
    else
        status = builtin_run(sh, c->argc, c->argv);

    fflush(stdout);
    dup2(save_in, STDIN_FILENO);
    dup2(save_out, STDOUT_FILENO);
    close(save_in);
    close(save_out);
    return status;
}

/* ---- child side ------------------------------------------------------- */

static void reset_signals(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = SIG_DFL;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGINT,  &sa, NULL);
    sigaction(SIGQUIT, &sa, NULL);
    sigaction(SIGTSTP, &sa, NULL);
    sigaction(SIGTTIN, &sa, NULL);
    sigaction(SIGTTOU, &sa, NULL);
}

static void child_exec(Shell *sh, Command *c, int in_fd, int out_fd,
                       int close_a, int close_b, int background)
{
    reset_signals();

    if (in_fd != -1)  { dup2(in_fd, STDIN_FILENO);   close(in_fd);  }
    if (out_fd != -1) { dup2(out_fd, STDOUT_FILENO); close(out_fd); }
    if (close_a != -1) close(close_a);
    if (close_b != -1) close(close_b);

    if (background && in_fd == -1 && !c->infile) {      /* detach from terminal input */
        int nul = open("/dev/null", O_RDONLY);
        if (nul >= 0) { dup2(nul, STDIN_FILENO); close(nul); }
    }

    if (apply_redirections(c) < 0)
        _exit(1);

    if (builtin_is(c->argv[0])) {                       /* builtin inside a pipeline */
        int st = builtin_run(sh, c->argc, c->argv);
        fflush(stdout);
        _exit(st & 0xff);
    }

    execvp(c->argv[0], c->argv);
    if (errno == ENOENT)
        fprintf(stderr, "minishell: %s: command not found\n", c->argv[0]);
    else
        fprintf(stderr, "minishell: %s: %s\n", c->argv[0], strerror(errno));
    _exit(errno == ENOENT ? 127 : 126);
}

/* ---- foreground wait -------------------------------------------------- */

static int wait_foreground(Shell *sh, Job *job)
{
    int rc;
    int interrupted = 0;

    if (sh->interactive)
        tcsetpgrp(STDIN_FILENO, job->pgid);

    while (job->state == JOB_RUNNING) {
        int st;
        pid_t p = waitpid(-job->pgid, &st, WUNTRACED);
        if (p < 0) {
            if (errno == EINTR) continue;
            for (int i = 0; i < job->npids; i++)          /* ECHILD: nothing left */
                job->pstate[i] = PS_DONE;
            job->state = JOB_DONE;
            break;
        }
        if (WIFSIGNALED(st) && WTERMSIG(st) == SIGINT)
            interrupted = 1;
        jobs_mark_pid_status(&sh->jobs, p, st);
    }

    if (sh->interactive)
        tcsetpgrp(STDIN_FILENO, sh->pgid);

    if (job->state == JOB_STOPPED) {
        fprintf(stderr, "\n[%d]+  Stopped                 %s\n", job->id, job->cmd);
        return 128 + SIGTSTP;
    }
    rc = job->status;
    if (interrupted)
        fputc('\n', stderr);
    jobs_remove(&sh->jobs, job);
    return rc;
}

int executor_foreground_job(Shell *sh, Job *job)
{
    jobs_resume(&sh->jobs, job);
    if (kill(-job->pgid, SIGCONT) < 0 && errno != ESRCH)
        perror("minishell: kill");
    return wait_foreground(sh, job);
}

/* ---- pipeline --------------------------------------------------------- */

int execute_pipeline(Shell *sh, Pipeline *p, const char *cmdline)
{
    Command *c;
    pid_t *pids;
    int npids = 0, prev_read = -1, idx = 0, failed = 0;
    pid_t pgid = 0;
    Job *job;
    int status;

    /* A single builtin runs in the shell process. */
    if (p->ncmds == 1 && !p->background && builtin_is(p->head->argv[0]))
        return run_builtin_in_parent(sh, p->head);

    fflush(stdout);
    fflush(stderr);
    pids = calloc((size_t)p->ncmds, sizeof(pid_t));
    if (!pids) { perror("minishell: calloc"); return 1; }

    for (c = p->head; c; c = c->next, idx++) {
        int fds[2] = { -1, -1 };
        pid_t pid;

        if (c->next && pipe(fds) < 0) {
            perror("minishell: pipe");
            failed = 1;
            break;
        }
        pid = fork();
        if (pid < 0) {
            perror("minishell: fork");
            if (fds[0] != -1) { close(fds[0]); close(fds[1]); }
            failed = 1;
            break;
        }
        if (pid == 0) {
            setpgid(0, pgid);                         /* pgid==0 -> new group */
            child_exec(sh, c, prev_read, fds[1], fds[0], -1, p->background);
        }
        /* parent */
        if (pgid == 0) pgid = pid;
        setpgid(pid, pgid);                           /* avoid race with child */
        pids[npids++] = pid;
        if (prev_read != -1) close(prev_read);
        if (fds[1] != -1) close(fds[1]);
        prev_read = fds[0];
    }
    if (prev_read != -1) close(prev_read);

    if (npids == 0) {
        free(pids);
        return 1;
    }

    job = jobs_add(&sh->jobs, pgid, pids, npids, cmdline);
    free(pids);

    if (p->background) {
        fprintf(stderr, "[%d] %d\n", job->id, (int)pgid);
        return 0;
    }
    status = wait_foreground(sh, job);
    return failed ? 1 : status;
}
