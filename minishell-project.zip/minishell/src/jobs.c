/* jobs.c - linked-list job table protected by a mutex */
#include "jobs.h"
#include "utils.h"

#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>

void jobs_init(JobTable *t)
{
    t->head = NULL;
    pthread_mutex_init(&t->lock, NULL);
}

static void job_free(Job *j)
{
    free(j->pids);
    free(j->pstate);
    free(j->cmd);
    free(j);
}

void jobs_destroy(JobTable *t)
{
    Job *j = t->head;
    while (j) {
        Job *n = j->next;
        job_free(j);
        j = n;
    }
    t->head = NULL;
    pthread_mutex_destroy(&t->lock);
}

Job *jobs_add(JobTable *t, pid_t pgid, const pid_t *pids, int npids, const char *cmd)
{
    Job *j = xcalloc(1, sizeof *j), *it;

    j->pgid = pgid;
    j->npids = npids;
    j->pids = xcalloc((size_t)npids, sizeof(pid_t));
    j->pstate = xcalloc((size_t)npids, sizeof(ProcState));
    memcpy(j->pids, pids, (size_t)npids * sizeof(pid_t));
    j->cmd = xstrdup(cmd);
    j->state = JOB_RUNNING;

    pthread_mutex_lock(&t->lock);
    j->id = 1;                          /* highest existing id + 1 (like bash) */
    for (it = t->head; it; it = it->next)
        if (it->id >= j->id) j->id = it->id + 1;
    if (!t->head) {
        t->head = j;
    } else {
        for (it = t->head; it->next; it = it->next) ;
        it->next = j;
    }
    pthread_mutex_unlock(&t->lock);
    return j;
}

Job *jobs_find_by_id(JobTable *t, int id)
{
    Job *j;
    pthread_mutex_lock(&t->lock);
    for (j = t->head; j && j->id != id; j = j->next) ;
    pthread_mutex_unlock(&t->lock);
    return j;
}

static Job *find_pid_unlocked(JobTable *t, pid_t pid)
{
    for (Job *j = t->head; j; j = j->next)
        for (int i = 0; i < j->npids; i++)
            if (j->pids[i] == pid)
                return j;
    return NULL;
}

Job *jobs_find_by_pid(JobTable *t, pid_t pid)
{
    Job *j;
    pthread_mutex_lock(&t->lock);
    j = find_pid_unlocked(t, pid);
    pthread_mutex_unlock(&t->lock);
    return j;
}

Job *jobs_last(JobTable *t)
{
    Job *j, *last = NULL;
    pthread_mutex_lock(&t->lock);
    for (j = t->head; j; j = j->next)
        last = j;
    pthread_mutex_unlock(&t->lock);
    return last;
}

void jobs_remove(JobTable *t, Job *job)
{
    Job **pp;
    pthread_mutex_lock(&t->lock);
    for (pp = &t->head; *pp; pp = &(*pp)->next) {
        if (*pp == job) {
            *pp = job->next;
            job_free(job);
            break;
        }
    }
    pthread_mutex_unlock(&t->lock);
}

int jobs_count(JobTable *t)
{
    int n = 0;
    pthread_mutex_lock(&t->lock);
    for (Job *j = t->head; j; j = j->next)
        n++;
    pthread_mutex_unlock(&t->lock);
    return n;
}

int decode_wait_status(int st)
{
    if (WIFEXITED(st))   return WEXITSTATUS(st);
    if (WIFSIGNALED(st)) return 128 + WTERMSIG(st);
    return 0;
}

static void recompute_state(Job *j)
{
    int live = 0, running = 0;
    for (int i = 0; i < j->npids; i++) {
        if (j->pstate[i] != PS_DONE) live++;
        if (j->pstate[i] == PS_RUNNING) running++;
    }
    if (live == 0)         j->state = JOB_DONE;
    else if (running > 0)  j->state = JOB_RUNNING;
    else                   j->state = JOB_STOPPED;
}

int jobs_mark_pid_status(JobTable *t, pid_t pid, int st)
{
    Job *j;
    int found = 0;

    pthread_mutex_lock(&t->lock);
    j = find_pid_unlocked(t, pid);
    if (j) {
        for (int i = 0; i < j->npids; i++) {
            if (j->pids[i] != pid) continue;
            found = 1;
            if (WIFEXITED(st) || WIFSIGNALED(st)) {
                j->pstate[i] = PS_DONE;
                if (i == j->npids - 1)
                    j->status = decode_wait_status(st);
            } else if (WIFSTOPPED(st)) {
                j->pstate[i] = PS_STOPPED;
            } else if (WIFCONTINUED(st)) {
                j->pstate[i] = PS_RUNNING;
            }
            break;
        }
        recompute_state(j);
    }
    pthread_mutex_unlock(&t->lock);
    return found;
}

void jobs_resume(JobTable *t, Job *job)
{
    pthread_mutex_lock(&t->lock);
    for (int i = 0; i < job->npids; i++)
        if (job->pstate[i] == PS_STOPPED)
            job->pstate[i] = PS_RUNNING;
    recompute_state(job);
    pthread_mutex_unlock(&t->lock);
}

void jobs_update(JobTable *t)
{
    for (;;) {
        int st;
        pid_t p = waitpid(-1, &st, WNOHANG | WUNTRACED | WCONTINUED);
        if (p <= 0)
            break;
        jobs_mark_pid_status(t, p, st);
    }
}

const char *job_state_name(JobState s)
{
    switch (s) {
    case JOB_RUNNING: return "Running";
    case JOB_STOPPED: return "Stopped";
    default:          return "Done";
    }
}

void jobs_notify_done(JobTable *t, FILE *out)
{
    Job *j, *next;
    pthread_mutex_lock(&t->lock);
    j = t->head;
    while (j) {
        next = j->next;
        if (j->state == JOB_DONE) {
            Job **pp;
            if (out && j->status == 0)
                fprintf(out, "[%d]+  Done                    %s\n", j->id, j->cmd);
            else if (out)
                fprintf(out, "[%d]+  Exit %-19d %s\n", j->id, j->status, j->cmd);
            for (pp = &t->head; *pp; pp = &(*pp)->next) {
                if (*pp == j) { *pp = j->next; break; }
            }
            job_free(j);
        }
        j = next;
    }
    pthread_mutex_unlock(&t->lock);
}

void jobs_print(JobTable *t, FILE *out)
{
    Job *last;
    pthread_mutex_lock(&t->lock);
    for (last = t->head; last && last->next; last = last->next) ;
    for (Job *j = t->head; j; j = j->next)
        fprintf(out, "[%d]%c  %-10s  pgid=%d  %s\n", j->id, j == last ? '+' : ' ',
                job_state_name(j->state), (int)j->pgid, j->cmd);
    pthread_mutex_unlock(&t->lock);
}
