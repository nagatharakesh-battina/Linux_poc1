/* monitor.c - periodic sampling thread: load average, memory, disk */
#include "monitor.h"

#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <sys/statvfs.h>
#include <unistd.h>

#define LOAD_FACTOR_ALERT 1.0     /* load1 > ncpu * factor */
#define MEM_ALERT_PCT     90.0
#define DISK_ALERT_PCT    90.0

int parse_loadavg(const char *text, double out[3])
{
    return sscanf(text, "%lf %lf %lf", &out[0], &out[1], &out[2]) == 3 ? 0 : -1;
}

int parse_meminfo(const char *text, unsigned long *total_kb, unsigned long *avail_kb)
{
    const char *p;
    int have_total = 0, have_avail = 0;

    if ((p = strstr(text, "MemTotal:")) && sscanf(p, "MemTotal: %lu", total_kb) == 1)
        have_total = 1;
    if ((p = strstr(text, "MemAvailable:")) && sscanf(p, "MemAvailable: %lu", avail_kb) == 1)
        have_avail = 1;
    return (have_total && have_avail) ? 0 : -1;
}

static int slurp(const char *path, char *buf, size_t len)
{
    FILE *fp = fopen(path, "r");
    size_t n;
    if (!fp) return -1;
    n = fread(buf, 1, len - 1, fp);
    buf[n] = '\0';
    fclose(fp);
    return 0;
}

int metrics_collect(SystemMetrics *m)
{
    char buf[8192];
    double load[3] = {0, 0, 0};
    struct statvfs vfs;

    memset(m, 0, sizeof *m);
    m->ncpu = (int)sysconf(_SC_NPROCESSORS_ONLN);
    if (m->ncpu < 1) m->ncpu = 1;

    if (slurp("/proc/loadavg", buf, sizeof buf) == 0 && parse_loadavg(buf, load) == 0) {
        m->load1 = load[0]; m->load5 = load[1]; m->load15 = load[2];
    }
    if (slurp("/proc/meminfo", buf, sizeof buf) == 0 &&
        parse_meminfo(buf, &m->mem_total_kb, &m->mem_avail_kb) == 0 && m->mem_total_kb > 0) {
        m->mem_used_pct = 100.0 * (double)(m->mem_total_kb - m->mem_avail_kb) / (double)m->mem_total_kb;
    }
    if (slurp("/proc/uptime", buf, sizeof buf) == 0)
        sscanf(buf, "%lf", &m->uptime_sec);
    if (statvfs("/", &vfs) == 0) {
        m->disk_total = (unsigned long long)vfs.f_blocks * vfs.f_frsize;
        m->disk_free  = (unsigned long long)vfs.f_bavail * vfs.f_frsize;
        if (m->disk_total > 0)
            m->disk_used_pct = 100.0 * (double)(m->disk_total - m->disk_free) / (double)m->disk_total;
    }
    return 0;
}

void metrics_print(const SystemMetrics *m, FILE *out)
{
    long up = (long)m->uptime_sec;
    fprintf(out, "CPUs        : %d\n", m->ncpu);
    fprintf(out, "Load average: %.2f %.2f %.2f\n", m->load1, m->load5, m->load15);
    fprintf(out, "Memory      : %.1f%% used (%lu MB of %lu MB)\n", m->mem_used_pct,
            (m->mem_total_kb - m->mem_avail_kb) / 1024, m->mem_total_kb / 1024);
    fprintf(out, "Disk (/)    : %.1f%% used (%llu MB free of %llu MB)\n", m->disk_used_pct,
            m->disk_free / (1024 * 1024), m->disk_total / (1024 * 1024));
    fprintf(out, "Uptime      : %ldd %ldh %ldm\n", up / 86400, (up % 86400) / 3600, (up % 3600) / 60);
}

int metrics_check_alerts(const SystemMetrics *m, char *buf, size_t len)
{
    int n = 0;
    size_t used = 0;
    char part[128];

    if (len) buf[0] = '\0';
    if (m->load1 > m->ncpu * LOAD_FACTOR_ALERT) {
        snprintf(part, sizeof part, "high load %.2f (cpus=%d); ", m->load1, m->ncpu);
        n++;
        if (used + strlen(part) < len) { strcat(buf, part); used += strlen(part); }
    }
    if (m->mem_used_pct > MEM_ALERT_PCT) {
        snprintf(part, sizeof part, "memory %.1f%% used; ", m->mem_used_pct);
        n++;
        if (used + strlen(part) < len) { strcat(buf, part); used += strlen(part); }
    }
    if (m->disk_used_pct > DISK_ALERT_PCT) {
        snprintf(part, sizeof part, "disk %.1f%% used; ", m->disk_used_pct);
        n++;
        if (used + strlen(part) < len) { strcat(buf, part); used += strlen(part); }
    }
    return n;
}

void monitor_init(Monitor *m, Logger *alert_log)
{
    pthread_condattr_t attr;
    memset(m, 0, sizeof *m);
    pthread_mutex_init(&m->lock, NULL);
    pthread_condattr_init(&attr);
    pthread_condattr_setclock(&attr, CLOCK_MONOTONIC);
    pthread_cond_init(&m->cond, &attr);
    pthread_condattr_destroy(&attr);
    m->alert_log = alert_log;
}

static void *monitor_thread(void *arg)
{
    Monitor *m = arg;

    pthread_mutex_lock(&m->lock);
    while (!m->stop) {
        SystemMetrics sm;
        char alert[256];
        struct timespec ts;

        pthread_mutex_unlock(&m->lock);
        metrics_collect(&sm);                   /* slow work done without the lock */
        pthread_mutex_lock(&m->lock);

        m->latest = sm;
        m->has_sample = 1;
        m->samples++;
        if (metrics_check_alerts(&sm, alert, sizeof alert) > 0) {
            char tsb[32];
            m->alerts++;
            log_timestamp(tsb, sizeof tsb);
            logger_write(m->alert_log, "%s|ALERT|%s", tsb, alert);
        }

        clock_gettime(CLOCK_MONOTONIC, &ts);
        ts.tv_sec  += m->interval_ms / 1000;
        ts.tv_nsec += (long)(m->interval_ms % 1000) * 1000000L;
        if (ts.tv_nsec >= 1000000000L) { ts.tv_sec++; ts.tv_nsec -= 1000000000L; }
        while (!m->stop) {
            if (pthread_cond_timedwait(&m->cond, &m->lock, &ts) == ETIMEDOUT)
                break;
        }
    }
    pthread_mutex_unlock(&m->lock);
    return NULL;
}

int monitor_start(Monitor *m, unsigned interval_ms)
{
    pthread_mutex_lock(&m->lock);
    if (m->running) {
        pthread_mutex_unlock(&m->lock);
        return -1;
    }
    m->stop = 0;
    m->interval_ms = interval_ms ? interval_ms : 5000;
    if (pthread_create(&m->thread, NULL, monitor_thread, m) != 0) {
        pthread_mutex_unlock(&m->lock);
        return -1;
    }
    m->running = 1;
    pthread_mutex_unlock(&m->lock);
    return 0;
}

void monitor_stop(Monitor *m)
{
    pthread_mutex_lock(&m->lock);
    if (!m->running) {
        pthread_mutex_unlock(&m->lock);
        return;
    }
    m->stop = 1;
    pthread_cond_signal(&m->cond);
    pthread_mutex_unlock(&m->lock);

    pthread_join(m->thread, NULL);

    pthread_mutex_lock(&m->lock);
    m->running = 0;
    pthread_mutex_unlock(&m->lock);
}

int monitor_is_running(Monitor *m)
{
    int r;
    pthread_mutex_lock(&m->lock);
    r = m->running;
    pthread_mutex_unlock(&m->lock);
    return r;
}

int monitor_latest(Monitor *m, SystemMetrics *out)
{
    int r = -1;
    pthread_mutex_lock(&m->lock);
    if (m->has_sample) {
        *out = m->latest;
        r = 0;
    }
    pthread_mutex_unlock(&m->lock);
    return r;
}

unsigned long monitor_sample_count(Monitor *m)
{
    unsigned long n;
    pthread_mutex_lock(&m->lock);
    n = m->samples;
    pthread_mutex_unlock(&m->lock);
    return n;
}

void monitor_destroy(Monitor *m)
{
    monitor_stop(m);
    pthread_mutex_destroy(&m->lock);
    pthread_cond_destroy(&m->cond);
}
