/* threadpool.c - producer/consumer pool built on pthread mutex + condvars */
#include "threadpool.h"
#include "utils.h"

#include <stdlib.h>

static void *worker(void *arg)
{
    ThreadPool *tp = arg;

    for (;;) {
        Task *t;
        pthread_mutex_lock(&tp->lock);
        while (!tp->head && !tp->shutdown)
            pthread_cond_wait(&tp->cv_work, &tp->lock);
        if (!tp->head && tp->shutdown) {
            pthread_mutex_unlock(&tp->lock);
            break;
        }
        t = tp->head;
        tp->head = t->next;
        if (!tp->head) tp->tail = NULL;
        pthread_mutex_unlock(&tp->lock);

        t->fn(t->arg);
        free(t);

        pthread_mutex_lock(&tp->lock);
        if (--tp->pending == 0)
            pthread_cond_broadcast(&tp->cv_idle);
        pthread_mutex_unlock(&tp->lock);
    }
    return NULL;
}

ThreadPool *tp_create(int nthreads)
{
    ThreadPool *tp;
    if (nthreads < 1) nthreads = 1;
    tp = xcalloc(1, sizeof *tp);
    tp->threads = xcalloc((size_t)nthreads, sizeof(pthread_t));
    pthread_mutex_init(&tp->lock, NULL);
    pthread_cond_init(&tp->cv_work, NULL);
    pthread_cond_init(&tp->cv_idle, NULL);
    for (int i = 0; i < nthreads; i++) {
        if (pthread_create(&tp->threads[i], NULL, worker, tp) != 0)
            break;
        tp->nthreads++;
    }
    if (tp->nthreads == 0) {
        tp_destroy(tp);
        return NULL;
    }
    return tp;
}

int tp_submit(ThreadPool *tp, task_fn fn, void *arg)
{
    Task *t;
    if (!tp || !fn) return -1;
    t = xcalloc(1, sizeof *t);
    t->fn = fn;
    t->arg = arg;

    pthread_mutex_lock(&tp->lock);
    if (tp->shutdown) {
        pthread_mutex_unlock(&tp->lock);
        free(t);
        return -1;
    }
    if (tp->tail) tp->tail->next = t; else tp->head = t;
    tp->tail = t;
    tp->pending++;
    pthread_cond_signal(&tp->cv_work);
    pthread_mutex_unlock(&tp->lock);
    return 0;
}

void tp_wait(ThreadPool *tp)
{
    pthread_mutex_lock(&tp->lock);
    while (tp->pending > 0)
        pthread_cond_wait(&tp->cv_idle, &tp->lock);
    pthread_mutex_unlock(&tp->lock);
}

void tp_destroy(ThreadPool *tp)
{
    Task *t;
    if (!tp) return;
    pthread_mutex_lock(&tp->lock);
    tp->shutdown = 1;
    pthread_cond_broadcast(&tp->cv_work);
    pthread_mutex_unlock(&tp->lock);

    for (int i = 0; i < tp->nthreads; i++)
        pthread_join(tp->threads[i], NULL);

    for (t = tp->head; t; ) {                  /* free tasks never executed */
        Task *n = t->next;
        free(t);
        t = n;
    }
    pthread_mutex_destroy(&tp->lock);
    pthread_cond_destroy(&tp->cv_work);
    pthread_cond_destroy(&tp->cv_idle);
    free(tp->threads);
    free(tp);
}
