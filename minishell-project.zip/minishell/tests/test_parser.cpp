#include "test_util.hpp"

namespace {

class ParserTest : public ::testing::Test {
protected:
    Pipeline p{};
    char err[256]{};
    void TearDown() override { pipeline_free(&p); }
    ParseStatus parse(const char *line) {
        pipeline_free(&p);
        return parse_line(line, &p, err, sizeof err);
    }
};

TEST_F(ParserTest, SimpleCommand) {
    ASSERT_EQ(parse("ls -l /tmp"), PARSE_OK);
    ASSERT_EQ(p.ncmds, 1);
    EXPECT_EQ(p.head->argc, 3);
    EXPECT_STREQ(p.head->argv[0], "ls");
    EXPECT_STREQ(p.head->argv[1], "-l");
    EXPECT_STREQ(p.head->argv[2], "/tmp");
    EXPECT_EQ(p.head->argv[3], nullptr);
    EXPECT_FALSE(p.background);
}

TEST_F(ParserTest, ExtraWhitespaceIsIgnored) {
    ASSERT_EQ(parse("   echo    a \t  b   "), PARSE_OK);
    EXPECT_EQ(p.head->argc, 3);
}

TEST_F(ParserTest, EmptyAndCommentLines) {
    EXPECT_EQ(parse(""), PARSE_EMPTY);
    EXPECT_EQ(parse("    "), PARSE_EMPTY);
    EXPECT_EQ(parse("# only a comment"), PARSE_EMPTY);
    ASSERT_EQ(parse("echo hi # trailing comment"), PARSE_OK);
    EXPECT_EQ(p.head->argc, 2);
}

TEST_F(ParserTest, DoubleQuotesKeepSpaces) {
    ASSERT_EQ(parse("echo \"hello   world\" x"), PARSE_OK);
    ASSERT_EQ(p.head->argc, 3);
    EXPECT_STREQ(p.head->argv[1], "hello   world");
}

TEST_F(ParserTest, SingleQuotesAreLiteral) {
    setenv("MS_TEST_VAR", "value", 1);
    ASSERT_EQ(parse("echo '$MS_TEST_VAR | > &'"), PARSE_OK);
    ASSERT_EQ(p.head->argc, 2);
    EXPECT_STREQ(p.head->argv[1], "$MS_TEST_VAR | > &");
}

TEST_F(ParserTest, EmptyQuotedArgumentIsKept) {
    ASSERT_EQ(parse("echo \"\" x"), PARSE_OK);
    ASSERT_EQ(p.head->argc, 3);
    EXPECT_STREQ(p.head->argv[1], "");
}

TEST_F(ParserTest, BackslashEscapes) {
    ASSERT_EQ(parse("echo a\\ b \\| c"), PARSE_OK);
    ASSERT_EQ(p.head->argc, 4);
    EXPECT_STREQ(p.head->argv[1], "a b");
    EXPECT_STREQ(p.head->argv[2], "|");
}

TEST_F(ParserTest, EnvironmentExpansion) {
    setenv("MS_TEST_VAR", "value", 1);
    ASSERT_EQ(parse("echo $MS_TEST_VAR \"x-$MS_TEST_VAR-y\""), PARSE_OK);
    EXPECT_STREQ(p.head->argv[1], "value");
    EXPECT_STREQ(p.head->argv[2], "x-value-y");
}

TEST_F(ParserTest, UnsetVariableExpandsToNothing) {
    unsetenv("MS_TEST_UNSET");
    ASSERT_EQ(parse("echo $MS_TEST_UNSET a"), PARSE_OK);
    EXPECT_EQ(p.head->argc, 2);           // the empty word is dropped
}

TEST_F(ParserTest, LastStatusExpansion) {
    parser_set_last_status(42);
    ASSERT_EQ(parse("echo $?"), PARSE_OK);
    EXPECT_STREQ(p.head->argv[1], "42");
    parser_set_last_status(0);
}

TEST_F(ParserTest, PipelineOfThree) {
    ASSERT_EQ(parse("cat f | grep x | wc -l"), PARSE_OK);
    ASSERT_EQ(p.ncmds, 3);
    EXPECT_STREQ(p.head->argv[0], "cat");
    EXPECT_STREQ(p.head->next->argv[0], "grep");
    EXPECT_STREQ(p.head->next->next->argv[0], "wc");
    EXPECT_EQ(p.head->next->next->next, nullptr);
}

TEST_F(ParserTest, PipeWithoutSpaces) {
    ASSERT_EQ(parse("a|b|c"), PARSE_OK);
    EXPECT_EQ(p.ncmds, 3);
}

TEST_F(ParserTest, InputRedirection) {
    ASSERT_EQ(parse("sort < in.txt"), PARSE_OK);
    EXPECT_STREQ(p.head->infile, "in.txt");
    EXPECT_EQ(p.head->outfile, nullptr);
    EXPECT_EQ(p.head->argc, 1);
}

TEST_F(ParserTest, OutputAndAppendRedirection) {
    ASSERT_EQ(parse("echo x > out.txt"), PARSE_OK);
    EXPECT_STREQ(p.head->outfile, "out.txt");
    EXPECT_EQ(p.head->append, 0);
    ASSERT_EQ(parse("echo x >> out.txt"), PARSE_OK);
    EXPECT_STREQ(p.head->outfile, "out.txt");
    EXPECT_EQ(p.head->append, 1);
}

TEST_F(ParserTest, RedirectionsBeforeAndAfterArguments) {
    ASSERT_EQ(parse("cat < in > out extra"), PARSE_OK);
    EXPECT_EQ(p.head->argc, 2);
    EXPECT_STREQ(p.head->infile, "in");
    EXPECT_STREQ(p.head->outfile, "out");
}

TEST_F(ParserTest, RedirectionInsidePipeline) {
    ASSERT_EQ(parse("cat < a | sort | uniq > b"), PARSE_OK);
    ASSERT_EQ(p.ncmds, 3);
    EXPECT_STREQ(p.head->infile, "a");
    EXPECT_STREQ(p.head->next->next->outfile, "b");
}

TEST_F(ParserTest, BackgroundFlag) {
    ASSERT_EQ(parse("sleep 10 &"), PARSE_OK);
    EXPECT_TRUE(p.background);
    EXPECT_EQ(p.head->argc, 2);
    ASSERT_EQ(parse("sleep 10&"), PARSE_OK);
    EXPECT_TRUE(p.background);
}

TEST_F(ParserTest, SyntaxErrors) {
    EXPECT_EQ(parse("echo \"oops"), PARSE_ERROR);
    EXPECT_NE(std::string(err).find("quote"), std::string::npos);
    EXPECT_EQ(parse("echo 'oops"), PARSE_ERROR);
    EXPECT_EQ(parse("| ls"), PARSE_ERROR);
    EXPECT_EQ(parse("ls |"), PARSE_ERROR);
    EXPECT_EQ(parse("ls | | wc"), PARSE_ERROR);
    EXPECT_EQ(parse("ls >"), PARSE_ERROR);
    EXPECT_EQ(parse("ls > | wc"), PARSE_ERROR);
    EXPECT_EQ(parse("ls & echo"), PARSE_ERROR);
    EXPECT_EQ(parse("> file"), PARSE_ERROR);
    EXPECT_EQ(p.head, nullptr);           // nothing leaks out on error
}

TEST_F(ParserTest, VeryLongLine) {
    std::string line = "echo";
    for (int i = 0; i < 5000; i++) line += " arg" + std::to_string(i);
    ASSERT_EQ(parse(line.c_str()), PARSE_OK);
    EXPECT_EQ(p.head->argc, 5001);
}

} // namespace
