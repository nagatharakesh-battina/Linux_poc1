// Audit, services and maintenance tests
#include "test_util.hpp"
#include <sys/time.h>
#include <unistd.h>

namespace {

// ------------------------------------------------------------------- audit
TEST(Audit, RecordFormat) {
    TempDir dir;
    Logger lg;
    ASSERT_EQ(logger_open(&lg, dir.file("audit.log").c_str()), 0);
    audit_record(&lg, "alice", 4242, 0, "ls -l | wc -l");
    audit_record(&lg, "alice", 4242, 1, "multi\nline\r\ncommand");
    logger_close(&lg);

    std::istringstream in(read_file(dir.file("audit.log")));
    std::string l1, l2, l3;
    std::getline(in, l1);
    std::getline(in, l2);
    EXPECT_FALSE(std::getline(in, l3));              // newline inside cmd must not split a record
    EXPECT_NE(l1.find("|alice|4242|0|ls -l | wc -l"), std::string::npos);
    EXPECT_NE(l2.find("|alice|4242|1|multi line  command"), std::string::npos);
    EXPECT_EQ(l1.size() > 20 && l1[4] == '-' && l1[13] == ':', true);   // timestamp prefix
}

TEST(Audit, SummarizeCountsAndTopCommands) {
    TempDir dir;
    write_file(dir.file("a.log"),
        "2026-11-06 09:00:00|bob|1|0|ls -l\n"
        "2026-11-06 09:00:01|bob|1|0|ls\n"
        "2026-11-06 09:00:02|bob|1|0|ls /tmp\n"
        "2026-11-06 09:00:03|bob|1|1|grep x f | wc\n"
        "2026-11-06 09:00:04|bob|1|127|nosuchcmd\n"
        "2026-11-06 09:00:05|bob|1|0|grep y f\n"
        "this line is garbage\n"
        "2026-11-06 09:00:06|bob|1|0|echo hi\n");
    AuditSummary s;
    ASSERT_EQ(audit_summarize(dir.file("a.log").c_str(), &s), 0);
    EXPECT_EQ(s.total, 7);
    EXPECT_EQ(s.succeeded, 5);
    EXPECT_EQ(s.failed, 2);
    EXPECT_STREQ(s.first_ts, "2026-11-06 09:00:00");
    EXPECT_STREQ(s.last_ts, "2026-11-06 09:00:06");
    ASSERT_GE(s.ntop, 3);
    EXPECT_STREQ(s.top[0].name, "ls");
    EXPECT_EQ(s.top[0].count, 3);
    EXPECT_STREQ(s.top[1].name, "grep");
    EXPECT_EQ(s.top[1].count, 2);
}

TEST(Audit, SummarizeMissingAndEmptyFile) {
    AuditSummary s;
    EXPECT_EQ(audit_summarize("/nonexistent/audit.log", &s), -1);
    TempDir dir;
    write_file(dir.file("e.log"), "");
    ASSERT_EQ(audit_summarize(dir.file("e.log").c_str(), &s), 0);
    EXPECT_EQ(s.total, 0);
    EXPECT_EQ(s.ntop, 0);
}

TEST(Audit, PrintReport) {
    AuditSummary s;
    memset(&s, 0, sizeof s);
    s.total = 4; s.succeeded = 3; s.failed = 1; s.ntop = 1;
    snprintf(s.top[0].name, sizeof s.top[0].name, "ls"); s.top[0].count = 4;
    char *buf = nullptr; size_t len = 0;
    FILE *f = open_memstream(&buf, &len);
    audit_print_report(&s, f);
    fclose(f);
    std::string out(buf);
    free(buf);
    EXPECT_NE(out.find("Audit Report"), std::string::npos);
    EXPECT_NE(out.find("Total commands  : 4"), std::string::npos);
    EXPECT_NE(out.find("75.0%"), std::string::npos);
    EXPECT_NE(out.find("ls"), std::string::npos);
}

TEST(Audit, TailReturnsLastLines) {
    TempDir dir;
    std::string body;
    for (int i = 1; i <= 20; i++) body += "line" + std::to_string(i) + "\n";
    write_file(dir.file("t.log"), body);
    char *buf = nullptr; size_t len = 0;
    FILE *f = open_memstream(&buf, &len);
    ASSERT_EQ(audit_tail(dir.file("t.log").c_str(), 3, f), 0);
    fclose(f);
    EXPECT_EQ(std::string(buf), "line18\nline19\nline20\n");
    free(buf);

    f = open_memstream(&buf, &len);
    ASSERT_EQ(audit_tail(dir.file("t.log").c_str(), 100, f), 0);   // more than exist
    fclose(f);
    EXPECT_EQ(count_lines(buf), 20);
    free(buf);
    EXPECT_EQ(audit_tail("/no/such", 3, stdout), -1);
}

// ---------------------------------------------------------------- services
TEST(Services, ParseProcStatus) {
    const char *text =
        "Name:\tnginx\nUmask:\t0022\nState:\tS (sleeping)\nTgid:\t812\nPid:\t812\n"
        "PPid:\t1\nVmSize:\t  9000 kB\nVmRSS:\t   4321 kB\nThreads:\t3\n";
    ProcInfo p;
    ASSERT_EQ(parse_proc_status(text, &p), 0);
    EXPECT_STREQ(p.name, "nginx");
    EXPECT_EQ(p.state, 'S');
    EXPECT_EQ(p.pid, 812);
    EXPECT_EQ(p.rss_kb, 4321);
}

TEST(Services, ParseProcStatusKernelThreadHasNoRss) {
    ProcInfo p;
    ASSERT_EQ(parse_proc_status("Name:\tkthreadd\nState:\tS (sleeping)\nPid:\t2\n", &p), 0);
    EXPECT_EQ(p.rss_kb, 0);
    EXPECT_EQ(parse_proc_status("nothing useful", &p), -1);
}

TEST(Services, ListContainsThisProcess) {
    int n = 0;
    ProcInfo *all = proc_list(&n);
    ASSERT_NE(all, nullptr);
    ASSERT_GT(n, 0);
    bool found = false;
    for (int i = 0; i < n; i++) if (all[i].pid == getpid()) found = true;
    EXPECT_TRUE(found);
    free(all);
}

TEST(Services, FindByNameFindsSelf) {
    // our own process name as the kernel sees it
    std::string comm = read_file("/proc/self/comm");
    while (!comm.empty() && comm.back() == '\n') comm.pop_back();
    pid_t pids[64];
    int n = proc_find_by_name(comm.c_str(), pids, 64);
    ASSERT_GE(n, 1);
    bool self = false;
    for (int i = 0; i < n; i++) if (pids[i] == getpid()) self = true;
    EXPECT_TRUE(self);
    EXPECT_EQ(proc_find_by_name("definitely-not-a-process-name", pids, 64), 0);
}

TEST(Services, PrintFilters) {
    ProcInfo a[2];
    memset(a, 0, sizeof a);
    a[0].pid = 1; a[0].state = 'S'; snprintf(a[0].name, sizeof a[0].name, "sshd");
    a[1].pid = 2; a[1].state = 'R'; snprintf(a[1].name, sizeof a[1].name, "cron");
    char *buf = nullptr; size_t len = 0;
    FILE *f = open_memstream(&buf, &len);
    proc_print(a, 2, "ssh", f);
    fclose(f);
    std::string out(buf);
    free(buf);
    EXPECT_NE(out.find("sshd"), std::string::npos);
    EXPECT_EQ(out.find("cron"), std::string::npos);
    EXPECT_NE(out.find("(1 processes)"), std::string::npos);
}

// ------------------------------------------------------------- maintenance
static void set_age_days(const std::string &path, int days) {
    struct timeval tv[2];
    gettimeofday(&tv[0], nullptr);
    tv[0].tv_sec -= (time_t)days * 86400;
    tv[1] = tv[0];
    utimes(path.c_str(), tv);
}

class CleanupTest : public ::testing::Test {
protected:
    TempDir dir;
    void SetUp() override {
        write_file(dir.file("old.tmp"), "12345");
        write_file(dir.file("old.log"), "123");
        write_file(dir.file("old.bak"), "1");
        write_file(dir.file("new.tmp"), "x");
        write_file(dir.file("old.txt"), "keep me");       // unsafe suffix
        write_file(dir.file("old.conf"), "keep me too");
        mkdir(dir.file("sub.tmp").c_str(), 0755);         // directory with safe suffix
        for (auto n : {"old.tmp", "old.log", "old.bak", "old.txt", "old.conf"})
            set_age_days(dir.file(n), 40);
    }
};

TEST_F(CleanupTest, DryRunRemovesNothing) {
    CleanupResult r;
    FILE *devnull = fopen("/dev/null", "w");
    ASSERT_EQ(cleanup_dir(dir.path().c_str(), 30, 0, devnull, &r), 0);
    fclose(devnull);
    EXPECT_EQ(r.matched, 3);
    EXPECT_EQ(r.removed, 0);
    EXPECT_EQ(r.bytes, 9);
    EXPECT_TRUE(file_exists(dir.file("old.tmp")));
}

TEST_F(CleanupTest, ForceRemovesOnlySafeOldFiles) {
    CleanupResult r;
    FILE *devnull = fopen("/dev/null", "w");
    ASSERT_EQ(cleanup_dir(dir.path().c_str(), 30, 1, devnull, &r), 0);
    fclose(devnull);
    EXPECT_EQ(r.removed, 3);
    EXPECT_FALSE(file_exists(dir.file("old.tmp")));
    EXPECT_FALSE(file_exists(dir.file("old.log")));
    EXPECT_FALSE(file_exists(dir.file("old.bak")));
    EXPECT_TRUE(file_exists(dir.file("new.tmp")));        // too recent
    EXPECT_TRUE(file_exists(dir.file("old.txt")));        // unsafe suffix
    EXPECT_TRUE(file_exists(dir.file("old.conf")));
    EXPECT_TRUE(file_exists(dir.file("sub.tmp")));        // directory untouched
}

TEST_F(CleanupTest, LargeThresholdMatchesNothing) {
    CleanupResult r;
    FILE *devnull = fopen("/dev/null", "w");
    ASSERT_EQ(cleanup_dir(dir.path().c_str(), 365, 1, devnull, &r), 0);
    fclose(devnull);
    EXPECT_EQ(r.matched, 0);
    EXPECT_TRUE(file_exists(dir.file("old.tmp")));
}

TEST(Cleanup, MissingDirectoryFails) {
    CleanupResult r;
    EXPECT_EQ(cleanup_dir("/no/such/dir", 1, 0, stdout, &r), -1);
}

} // namespace
