#!/usr/bin/env bash
# Black-box tests: drive the real binary the way a user (or cron job) would.
set -u
cd "$(dirname "$0")/.."
BIN=./bin/minishell
export MINISHELL_HOME="$(mktemp -d)"
TMP="$(mktemp -d)"
trap 'rm -rf "$MINISHELL_HOME" "$TMP"' EXIT
pass=0; fail=0

check() {   # check <name> <expected> <actual>
    if [ "$2" == "$3" ]; then pass=$((pass+1)); printf '  PASS  %s\n' "$1"
    else fail=$((fail+1)); printf '  FAIL  %s\n        expected: %q\n        actual  : %q\n' "$1" "$2" "$3"; fi
}

[ -x "$BIN" ] || { echo "build first: make"; exit 2; }

check "version"            "minishell 1.0.0"  "$($BIN --version)"
check "-c echo"            "hi"               "$($BIN -c 'echo hi')"
check "-c exit code"       "7"                "$($BIN -c 'exit 7'; echo $?)"
check "-c failing cmd"     "1"                "$($BIN -c 'false'; echo $?)"
check "pipe"               "3"                "$($BIN -c 'echo a b c | wc -w')"
check "redirect out/in"    "x y"              "$($BIN -c "echo x y > $TMP/f; cat < $TMP/f")"
check "append"             "1 2"              "$($BIN -c "echo 1 > $TMP/g; echo 2 >> $TMP/g; cat $TMP/g | tr '\n' ' ' | sed 's/ $//'")"
check "and/or"             "ok"               "$($BIN -c 'false || echo ok')"
check "quotes"             "a  b"             "$($BIN -c 'echo "a  b"')"
check "var expansion"      "v1"               "$(MS_V=v1 $BIN -c 'echo $MS_V')"
check "not found => 127"   "127"              "$($BIN -c 'nosuchcmd_q' 2>/dev/null; echo $?)"

printf 'echo from stdin\nexit 4\n' > "$TMP/in.msh"
check "stdin script"       "from stdin"       "$($BIN < "$TMP/in.msh")"
check "stdin exit code"    "4"                "$($BIN < "$TMP/in.msh" >/dev/null; echo $?)"
check "script file"        "from stdin"       "$($BIN "$TMP/in.msh")"
check "missing script"     "127"              "$($BIN /no/such/file 2>/dev/null; echo $?)"

out="$($BIN -c 'loganalyze -p ERROR samples/app.log samples/web.log samples/db.log' | tail -1 | tr -s ' ')"
check "loganalyze total"   "TOTAL 17 5 3 9 5" "$out"

check "bg job + jobs"      "Done"             "$(printf 'sleep 0.2 &\nsleep 0.5\njobs\n' | $BIN 2>/dev/null | grep -o Done | head -1)"

printf 'echo one\nfalse\nls /nonexistent_zz\n' | $BIN >/dev/null 2>&1
check "audit lines"        "3"                "$(wc -l < "$MINISHELL_HOME/audit.log" | tr -d ' ' | awk '{print ($1>=3)?3:$1}')"
check "audit failure rows" "2"                "$(grep -c '|[1-9][0-9]*|' "$MINISHELL_HOME/audit.log" | awk '{print ($1>=2)?2:$1}')"

timeout 20 $BIN scripts/demo.msh >/dev/null 2>&1
check "demo script exits 0" "0"               "$?"

echo
echo "integration: $pass passed, $fail failed"
[ "$fail" -eq 0 ]
