# MiniShell - bash-like shell in C for an IT Infrastructure Management Console

A Linux command-line interpreter written in C (GCC, Makefile) that mimics core Bash features
and adds tools for system administrators: health monitoring, service checks, multi-threaded
log analysis, maintenance automation and audit reports.

## Build and run
```bash
sudo apt install build-essential valgrind libgtest-dev   # Ubuntu / Debian (WSL works too)
make                    # builds bin/minishell
./bin/minishell         # interactive
./bin/minishell -c "ls | wc -l"
./bin/minishell scripts/demo.msh
```
State (history, audit log, alerts) lives in `$MINISHELL_HOME` (default `~/.minishell`).

## Features by level
| Level | Feature | Source |
|---|---|---|
| 1 | Custom prompt `user@host:cwd$`, external + built-in commands | `shell.c`, `builtins.c` |
| 2 | `fork` / `execvp` / `waitpid`, background execution `&` | `executor.c` |
| 3 | Redirection `<  >  >>` via `dup2` | `executor.c` |
| 4 | Pipes `a \| b \| c` via `pipe` | `executor.c` |
| 5 | History (linked list, file persistence, `!!` `!N` `!prefix`) | `history.c` |
| 6 | Job control: `jobs fg bg kill`, Ctrl-C / Ctrl-Z, process groups | `jobs.c`, `executor.c` |
| + | Quotes, `$VAR`, `$?`, comments, `;` `&&` `\|\|` | `parser.c`, `shell.c` |

## Infrastructure commands
| Command | Purpose |
|---|---|
| `sysinfo` | CPU load, memory, disk, uptime (+ alerts over threshold) |
| `monitor [status\|start [s]\|stop]` | Background **thread** sampling `/proc`, writes `alerts.log` |
| `services list [filter]` / `services status <name>` | Running processes / is service X up (exit code 0/1) |
| `loganalyze [-t N] [-p pat] files...` | Counts ERROR/WARN/INFO; **thread pool** analyses files in parallel |
| `cleanup <dir> <days> [--force]` | Removes stale `*.tmp *.log *.bak` (dry-run by default) |
| `audit [report\|tail [n]\|export file]` | Every command is recorded; summary report |
| `source <file>` | Run a maintenance script |

## Testing
```bash
make test          # 149 GoogleTest (C++) unit + end-to-end tests
make valgrind      # whole suite under Valgrind (leaks, invalid reads)
make valgrind-shell# the shell running scripts/demo.msh under Valgrind
make integration   # 20 black-box tests of the real binary
make asan          # AddressSanitizer + UBSan
make tsan          # ThreadSanitizer (data races)
make helgrind      # Valgrind Helgrind on the multithreaded tests
```
If linking fails on older Ubuntu, build GoogleTest from `/usr/src/googletest` or set
`GTEST_LIBS="-L/path -lgtest -lgtest_main -lpthread"`.

## Layout
```
include/  headers (C, usable from C++)      src/    implementation
tests/    gtest *.cpp + integration.sh      scripts/demo.msh   samples/*.log
```
